const Rota = require('../util/rota');
const db = require('../database/db');
const { html, redirecionar } = require('../util/http');
const { usuarioAtual, cookieVisitante, jaPassouPelaEntrada } = require('../util/autenticacao');
const { mostrar } = require('../util/mostra');
const loja = require('../util/loja');

const rota = new Rota();

const telas = [
  { caminho: '/',            view: 'index',      pagina: 'home',        titulo: 'VB Store | Sua roupa, seu jeito' },
  { caminho: '/feminino',    view: 'catalogo',  pagina: 'feminino',    titulo: 'Feminino | VB Store', cabecalho: 'Feminino', texto: 'Peças femininas para todos os momentos.' },
  { caminho: '/masculino',   view: 'catalogo',  pagina: 'masculino',   titulo: 'Masculino | VB Store', cabecalho: 'Masculino', texto: 'Peças masculinas com estilo e conforto.' },
  { caminho: '/lancamentos', view: 'lancamentos',  pagina: 'lancamentos', titulo: 'Lançamentos | VB Store', cabecalho: 'Lançamentos', texto: 'As novidades que acabaram de chegar.' },
  { caminho: '/acessorios',  view: 'catalogo',  pagina: 'acessorios',  titulo: 'Acessórios | VB Store', cabecalho: 'Acessórios', texto: 'Detalhes que completam o seu look.' },
  { caminho: '/busca',       view: 'catalogo',  pagina: 'busca',       titulo: 'Busca | VB Store', cabecalho: 'Resultados da busca', texto: '' },
  { caminho: '/favoritos',   view: 'favoritos', pagina: 'favoritos',   titulo: 'Favoritos | VB Store' },
  { caminho: '/carrinho',    view: 'carrinho',  pagina: 'carrinho',    titulo: 'Carrinho | VB Store' },
  { caminho: '/ajuda',       view: 'ajuda',     pagina: 'ajuda',       titulo: 'Ajuda | VB Store' }
];

for (const t of telas) {
  rota.get(t.caminho, (req, res) => {
    const usuario = usuarioAtual(req);
    if (t.caminho === '/' && !usuario && !jaPassouPelaEntrada(req)) return redirecionar(res, '/cadastro');
    html(res, 200, mostrar(t.view, { usuario, pagina: t.pagina, titulo: t.titulo, cabecalho: t.cabecalho || '', texto: t.texto || '', id: '' }));
  });
}

const telaEntrada = (modo) => (req, res) => {
  if (usuarioAtual(req)) return redirecionar(res, '/');
  html(res, 200, mostrar('entrar', { modo, pagina: 'entrar', titulo: (modo === 'cadastro' ? 'Criar conta' : 'Entrar') + ' | VB Store' }));
};
rota.get('/entrar', telaEntrada('entrar'));
rota.get('/cadastro', telaEntrada('cadastro'));

rota.get('/loja', (req, res) => redirecionar(res, '/', [cookieVisitante()]));

rota.get('/perfil', (req, res) => {
  const usuario = usuarioAtual(req);
  if (!usuario) return redirecionar(res, '/entrar');
  html(res, 200, mostrar('perfil', { usuario, pagina: 'perfil', titulo: 'Meu perfil | VB Store' }));
});

rota.get('/produto/:id', (req, res) => {
  const p = db.prepare('SELECT id, nome FROM produtos WHERE id = ?').get(Number(req.params.id));
  if (!p) return html(res, 404, mostrar('404', { usuario: usuarioAtual(req), pagina: '404', titulo: 'Página não encontrada | VB Store', id: '' }));
  html(res, 200, mostrar('produto', { usuario: usuarioAtual(req), pagina: 'produto', titulo: `${p.nome} | VB Store`, id: p.id }));
});

module.exports = rota;
