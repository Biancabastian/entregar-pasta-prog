const Rota = require('../util/rota');
const db = require('../database/db');
const { json, lerCorpo } = require('../util/http');

const rota = new Rota();
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

rota.post('/api/novidades', async (req, res) => {
  const { email } = await lerCorpo(req);
  const limpo = String(email || '').trim().toLowerCase();
  if (!EMAIL.test(limpo) || limpo.length > 120) return json(res, 400, { erro: 'Digite um e-mail válido.' });
  const r = db.prepare('INSERT OR IGNORE INTO novidades (email) VALUES (?)').run(limpo);
  json(res, 201, { mensagem: r.changes ? 'Pronto! Você vai receber nossas novidades.' : 'Este e-mail já está cadastrado.' });
});

module.exports = rota;
