const Rota = require('../util/rota');
const db = require('../database/db');
const { json, lerCorpo, sessao } = require('../util/http');

const rota = new Rota();

rota.get('/api/favoritos', (req, res) => {
  const sid = sessao(req, res);
  const linhas = db.prepare(`
    SELECT p.* FROM favoritos f JOIN produtos p ON p.id = f.produto_id
    WHERE f.sessao = ? ORDER BY f.criado_em DESC`).all(sid);
  json(res, 200, linhas.map((p) => ({ ...p, lancamento: !!p.lancamento, cores: JSON.parse(p.cores), tamanhos: JSON.parse(p.tamanhos) })));
});

rota.get('/api/favoritos/ids', (req, res) => {
  const sid = sessao(req, res);
  json(res, 200, db.prepare('SELECT produto_id FROM favoritos WHERE sessao = ?').all(sid).map((r) => r.produto_id));
});

rota.post('/api/favoritos', async (req, res) => {
  const sid = sessao(req, res);
  const { produto_id } = await lerCorpo(req);
  const id = Number(produto_id);
  if (!db.prepare('SELECT 1 FROM produtos WHERE id = ?').get(id)) return json(res, 404, { erro: 'Produto não encontrado.' });

  const existe = db.prepare('SELECT 1 FROM favoritos WHERE sessao = ? AND produto_id = ?').get(sid, id);
  if (existe) db.prepare('DELETE FROM favoritos WHERE sessao = ? AND produto_id = ?').run(sid, id);
  else db.prepare('INSERT INTO favoritos (sessao, produto_id) VALUES (?, ?)').run(sid, id);

  const total = db.prepare('SELECT COUNT(*) AS c FROM favoritos WHERE sessao = ?').get(sid).c;
  json(res, 200, { favorito: !existe, total });
});

module.exports = rota;
