const Rota = require('../util/rota');
const db = require('../database/db');
const { json, lerCorpo, sessao } = require('../util/http');
const { calcularTotais } = require('../util/preco');
const { usuarioAtual } = require('../util/autenticacao');

const rota = new Rota();

function lerCarrinho(sid) {
  const itens = db.prepare(`
    SELECT c.id, c.produto_id, c.cor, c.tamanho, c.quantidade,
           p.nome, p.preco, p.tipo, p.cores, p.estoque, p.imagem
    FROM carrinho c JOIN produtos p ON p.id = c.produto_id
    WHERE c.sessao = ? ORDER BY c.id DESC`).all(sid).map((i) => {
    const cores = JSON.parse(i.cores);
    const corEscolhida = cores.find((c) => c.nome === i.cor) || cores[0];
    const hex = corEscolhida.hex;
    return { id: i.id, produto_id: i.produto_id, nome: i.nome, cor: i.cor, hex, imagem: corEscolhida.imagem || i.imagem, tamanho: i.tamanho,
      quantidade: i.quantidade, preco: i.preco, subtotal: Math.round(i.preco * i.quantidade * 100) / 100, estoque: i.estoque };
  });
  return { itens, ...calcularTotais(itens) };
}

rota.get('/api/carrinho', (req, res) => {
  json(res, 200, lerCarrinho(sessao(req, res)));
});

rota.post('/api/carrinho', async (req, res) => {
  const sid = sessao(req, res);
  const { produto_id, cor, tamanho, quantidade } = await lerCorpo(req);
  const produto = db.prepare('SELECT * FROM produtos WHERE id = ?').get(Number(produto_id));
  if (!produto) return json(res, 404, { erro: 'Produto não encontrado.' });

  const cores = JSON.parse(produto.cores).map((c) => c.nome);
  const tamanhos = JSON.parse(produto.tamanhos);
  if (!cores.includes(cor)) return json(res, 400, { erro: 'Escolha uma cor.' });
  if (!tamanhos.includes(tamanho)) return json(res, 400, { erro: 'Escolha um tamanho.' });

  const qtd = Math.max(1, Math.min(10, parseInt(quantidade, 10) || 1));
  db.prepare(`
    INSERT INTO carrinho (sessao, produto_id, cor, tamanho, quantidade) VALUES (?, ?, ?, ?, ?)
    ON CONFLICT (sessao, produto_id, cor, tamanho)
    DO UPDATE SET quantidade = MIN(10, quantidade + excluded.quantidade)`).run(sid, produto.id, cor, tamanho, qtd);

  json(res, 201, lerCarrinho(sid));
});

rota.patch('/api/carrinho/:id', async (req, res) => {
  const sid = sessao(req, res);
  const { quantidade } = await lerCorpo(req);
  const qtd = parseInt(quantidade, 10);
  if (!(qtd >= 1 && qtd <= 10)) return json(res, 400, { erro: 'Quantidade deve ser entre 1 e 10.' });
  db.prepare('UPDATE carrinho SET quantidade = ? WHERE id = ? AND sessao = ?').run(qtd, Number(req.params.id), sid);
  json(res, 200, lerCarrinho(sid));
});

rota.delete('/api/carrinho/:id', (req, res) => {
  const sid = sessao(req, res);
  db.prepare('DELETE FROM carrinho WHERE id = ? AND sessao = ?').run(Number(req.params.id), sid);
  json(res, 200, lerCarrinho(sid));
});

rota.delete('/api/carrinho', (req, res) => {
  const sid = sessao(req, res);
  db.prepare('DELETE FROM carrinho WHERE sessao = ?').run(sid);
  json(res, 200, lerCarrinho(sid));
});

module.exports = rota;
module.exports.lerCarrinho = lerCarrinho;
