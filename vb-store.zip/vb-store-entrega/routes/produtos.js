const Rota = require('../util/rota');
const db = require('../database/db');
const { json } = require('../util/http');

const rota = new Rota();

function formatar(p) {
  return { ...p, lancamento: !!p.lancamento, cores: JSON.parse(p.cores), tamanhos: JSON.parse(p.tamanhos) };
}

rota.get('/api/produtos', (req, res) => {
  const q = req.query;
  const where = [];
  const params = [];

  const genero = q.get('genero');
  if (['feminino', 'masculino', 'unissex'].includes(genero)) { where.push('genero = ?'); params.push(genero); }

  const categoria = q.get('categoria');
  if (['roupa', 'acessorio'].includes(categoria)) { where.push('categoria = ?'); params.push(categoria); }

  if (q.get('lancamento') === '1') where.push('lancamento = 1');
  if (q.get('promocao') === '1') where.push('preco_antigo IS NOT NULL AND preco_antigo > preco');

  const busca = (q.get('q') || '').trim();
  if (busca) {
    where.push('(nome LIKE ? OR descricao LIKE ? OR tipo LIKE ?)');
    const termo = `%${busca}%`;
    params.push(termo, termo, termo);
  }

  const ordens = {
    preco_asc: 'preco ASC',
    preco_desc: 'preco DESC',
    nome: 'nome COLLATE NOCASE ASC',
    recentes: 'id DESC',
    desconto: '(preco_antigo - preco) * 1.0 / preco_antigo DESC, id ASC'
  };
  const ordem = ordens[q.get('ordem')] || 'id ASC';

  let sql = `SELECT * FROM produtos ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${ordem}`;
  const limite = parseInt(q.get('limite'), 10);
  if (limite > 0) { sql += ' LIMIT ?'; params.push(limite); }

  json(res, 200, db.prepare(sql).all(...params).map(formatar));
});

rota.get('/api/produtos/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM produtos WHERE id = ?').get(Number(req.params.id));
  if (!p) return json(res, 404, { erro: 'Produto não encontrado.' });
  const relacionados = db.prepare(
    'SELECT * FROM produtos WHERE id != ? AND categoria = ? AND (genero = ? OR genero = ?) ORDER BY RANDOM() LIMIT 4'
  ).all(p.id, p.categoria, p.genero, 'unissex').map(formatar);
  json(res, 200, { ...formatar(p), relacionados });
});

rota.get('/api/slides', (req, res) => {
  const pagina = ['home', 'feminino', 'masculino'].includes(req.query.get('pagina')) ? req.query.get('pagina') : 'home';
  const linhas = db.prepare(`
    SELECT s.*, p.tipo AS produto_tipo, p.cores AS produto_cores
    FROM slides s LEFT JOIN produtos p ON p.id = s.produto_id
    WHERE s.pagina = ? ORDER BY s.ordem`).all(pagina);
  json(res, 200, linhas.map((s) => {
    const cores = s.produto_cores ? JSON.parse(s.produto_cores) : [];
    return { ...s, produto_cores: undefined, cor: cores[0]?.hex || '#888888' };
  }));
});


module.exports = rota;
