const Rota = require('../util/rota');
const db = require('../database/db');
const { json, lerCorpo, sessao } = require('../util/http');
const { recomendar, TABELAS, ORDEM } = require('../util/tamanhos');

const rota = new Rota();

rota.post('/api/provador', async (req, res) => {
  const sid = sessao(req, res);
  const entrada = await lerCorpo(req);
  const r = recomendar(entrada);
  if (r.erro) return json(res, 400, { erro: r.erro });

  db.prepare(`INSERT INTO medidas_provador
    (sessao, genero, altura, peso, busto_peito, cintura, quadril, caimento, tamanho_recomendado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
    sid, r.genero,
    Number(entrada.altura) || null, Number(entrada.peso) || null,
    Number(entrada.busto) || null, Number(entrada.cintura) || null, Number(entrada.quadril) || null,
    entrada.caimento || 'normal', r.tamanho);

  json(res, 200, r);
});

rota.get('/api/provador/tabela', (req, res) => {
  json(res, 200, { ordem: ORDEM, tabelas: TABELAS });
});

module.exports = rota;
