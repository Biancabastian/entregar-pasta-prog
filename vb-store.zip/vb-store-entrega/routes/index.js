const Rota = require('../util/rota');

const rotas = new Rota();
rotas.usar(require('./paginas'));
rotas.usar(require('./produtos'));
rotas.usar(require('./favoritos'));
rotas.usar(require('./carrinho'));
rotas.usar(require('./provador'));
rotas.usar(require('./novidades'));
rotas.usar(require('./autenticacao'));

module.exports = rotas;
