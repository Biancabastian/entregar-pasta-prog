const Rota = require('../util/rota');
const db = require('../database/db');
const { json, lerCorpo } = require('../util/http');
const { limitado, liberar, hashSenha, conferirSenha, abrirSessao, fecharSessao, usuarioAtual } = require('../util/autenticacao');

const rota = new Rota();
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const exigirJson = (req, res) => {
  if (String(req.headers['content-type'] || '').includes('application/json')) return true;
  json(res, 415, { erro: 'Requisição inválida.' });
  return false;
};

const publico = (u) => ({ id: u.id, nome: u.nome, email: u.email });

rota.post('/api/autenticacao/cadastro', async (req, res) => {
  if (!exigirJson(req, res)) return;
  if (limitado(req)) return json(res, 429, { erro: 'Muitas tentativas. Aguarde alguns minutos.' });
  const { nome, email, senha } = await lerCorpo(req);
  const n = String(nome || '').trim().replace(/\s+/g, ' ');
  const e = String(email || '').trim().toLowerCase();
  const s = String(senha || '');
  if (n.length < 2 || n.length > 80) return json(res, 400, { erro: 'Digite seu nome.' });
  if (!EMAIL.test(e) || e.length > 120) return json(res, 400, { erro: 'Digite um e-mail válido.' });
  if (s.length < 6 || s.length > 72) return json(res, 400, { erro: 'A senha deve ter de 6 a 72 caracteres.' });
  if (db.prepare('SELECT 1 FROM usuarios WHERE email = ?').get(e)) {
    return json(res, 409, { erro: 'Este e-mail já tem cadastro. Tente entrar.' });
  }
  const r = db.prepare('INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)').run(n, e, hashSenha(s));
  res.setHeader('Set-Cookie', abrirSessao(Number(r.lastInsertRowid)));
  json(res, 201, { usuario: { id: Number(r.lastInsertRowid), nome: n, email: e } });
});

rota.post('/api/autenticacao/entrar', async (req, res) => {
  if (!exigirJson(req, res)) return;
  if (limitado(req)) return json(res, 429, { erro: 'Muitas tentativas. Aguarde alguns minutos.' });
  const { email, senha } = await lerCorpo(req);
  const e = String(email || '').trim().toLowerCase();
  const u = db.prepare('SELECT * FROM usuarios WHERE email = ?').get(e);
  if (!u || !conferirSenha(String(senha || ''), u.senha_hash)) {
    return json(res, 401, { erro: 'E-mail ou senha incorretos.' });
  }
  liberar(req);
  res.setHeader('Set-Cookie', abrirSessao(u.id));
  json(res, 200, { usuario: publico(u) });
});

rota.post('/api/autenticacao/sair', (req, res) => {
  if (!exigirJson(req, res)) return;
  res.setHeader('Set-Cookie', fecharSessao(req));
  json(res, 200, { ok: true });
});

rota.get('/api/autenticacao/eu', (req, res) => {
  const u = usuarioAtual(req);
  json(res, 200, { usuario: u ? publico(u) : null });
});

rota.patch('/api/autenticacao/perfil', async (req, res) => {
  if (!exigirJson(req, res)) return;
  const u = usuarioAtual(req);
  if (!u) return json(res, 401, { erro: 'Entre na sua conta.' });
  const { nome } = await lerCorpo(req);
  const n = String(nome || '').trim().replace(/\s+/g, ' ');
  if (n.length < 2 || n.length > 80) return json(res, 400, { erro: 'Digite seu nome.' });
  db.prepare('UPDATE usuarios SET nome = ? WHERE id = ?').run(n, u.id);
  json(res, 200, { usuario: { ...publico(u), nome: n } });
});

module.exports = rota;
