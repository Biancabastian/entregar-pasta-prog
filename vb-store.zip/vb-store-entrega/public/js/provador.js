(function () {
  const modal = document.getElementById('provador');
  const form = document.getElementById('provForm');
  const erro = document.getElementById('provErro');
  const resultado = document.getElementById('provResultado');
  const usar = document.getElementById('provUsar');
  let ultimoFoco = null;
  let tamanhoSugerido = null;

  function ajustarGenero() {
    const g = form.genero.value;
    document.getElementById('rotuloBusto').textContent = g === 'masculino' ? 'Peito (cm)' : 'Busto (cm)';
    document.getElementById('campoQuadril').hidden = g === 'masculino';
  }

  function abrir(generoInicial) {
    ultimoFoco = document.activeElement;
    if (generoInicial) {
      const radio = form.querySelector(`input[name="genero"][value="${generoInicial}"]`);
      if (radio) radio.checked = true;
    }
    ajustarGenero();
    modal.hidden = false;
    document.body.classList.add('modal-aberto');
    form.busto.focus();
  }

  function fechar() {
    modal.hidden = true;
    document.body.classList.remove('modal-aberto');
    if (ultimoFoco) ultimoFoco.focus();
  }

  VB.abrirProvador = abrir;

  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-abrir-provador]')) {
      e.preventDefault();
      const pagina = document.body.dataset.pagina;
      abrir(pagina === 'masculino' || pagina === 'feminino' ? pagina : VB.generoProduto);
    }
    if (e.target.closest('[data-fechar-provador]')) fechar();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !modal.hidden) fechar(); });

  form.addEventListener('change', (e) => { if (e.target.name === 'genero') ajustarGenero(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    erro.hidden = true;
    const dados = Object.fromEntries(new FormData(form).entries());
    try {
      const r = await VB.api('/api/provador', { method: 'POST', body: dados });
      tamanhoSugerido = r.tamanho;
      document.getElementById('provTamanho').textContent = r.tamanho;
      document.getElementById('provResumo').textContent = r.resumo;
      document.getElementById('provObs').textContent = r.observacao || '';
      usar.hidden = document.body.dataset.pagina !== 'produto';
      form.hidden = true;
      resultado.hidden = false;
    } catch (err) {
      erro.textContent = err.message;
      erro.hidden = false;
    }
  });

  document.getElementById('provRefazer').addEventListener('click', () => {
    resultado.hidden = true;
    form.hidden = false;
    form.busto.focus();
  });

  usar.addEventListener('click', () => {
    document.dispatchEvent(new CustomEvent('provador:tamanho', { detail: { tamanho: tamanhoSugerido } }));
    fechar();
  });

  VB.api('/api/provador/tabela').then(({ ordem, tabelas }) => {
    const linha = (rotulo, lista) => `<tr><th>${rotulo}</th>${lista.map((v) => `<td>até ${v}</td>`).join('')}</tr>`;
    const cab = `<tr><th></th>${ordem.map((t) => `<th>${t}</th>`).join('')}</tr>`;
    document.getElementById('provTabela').innerHTML = `
      <h4>Feminino (cm)</h4>
      <table>${cab}${linha('Busto', tabelas.feminino.busto)}${linha('Cintura', tabelas.feminino.cintura)}${linha('Quadril', tabelas.feminino.quadril)}</table>
      <h4>Masculino (cm)</h4>
      <table>${cab}${linha('Peito', tabelas.masculino.busto)}${linha('Cintura', tabelas.masculino.cintura)}</table>`;
  }).catch(() => {});
})();
