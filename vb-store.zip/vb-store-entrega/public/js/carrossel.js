(function () {
  VB.carrossel = async function (pagina, el) {
    let slides = [];
    try { slides = await VB.api('/api/slides?pagina=' + pagina); } catch { return; }
    if (!slides.length) return;

    el.hidden = false;
    el.innerHTML = `
      <div class="car-trilho">
        ${slides.map((s, i) => `
          <div class="car-slide" role="group" aria-roledescription="slide" aria-label="${i + 1} de ${slides.length}">
            <img class="car-foto" src="${VB.esc(s.imagem)}" alt="${VB.esc(s.alt || '')}" ${i === 0 ? '' : 'loading="lazy"'}>
            <div class="car-texto">
              <h1>${VB.esc(s.titulo).replace(/\n/g, '<br>')} <span class="destaque">${VB.esc(s.destaque || '')}</span></h1>
              <p>${VB.esc(s.subtitulo || '')}</p>
              <div class="car-botoes">
                <a href="${VB.esc(s.link)}" class="btn btn-escuro">${VB.esc(s.botao)}</a>
                <button type="button" class="btn btn-borda" data-abrir-provador>Abrir provador
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 7a2 2 0 1 1 2 2c-1 .4-2 1-2 2v1M3 19l9-6 9 6z"/></svg>
                </button>
              </div>
            </div>
          </div>`).join('')}
      </div>
      <button class="car-seta car-ant" type="button" aria-label="Slide anterior">‹</button>
      <button class="car-seta car-prox" type="button" aria-label="Próximo slide">›</button>
      <div class="car-pontos" role="tablist">
        ${slides.map((_, i) => `<button type="button" role="tab" aria-label="Ir para o slide ${i + 1}" data-i="${i}"></button>`).join('')}
      </div>`;

    const trilho = el.querySelector('.car-trilho');
    const pontos = [...el.querySelectorAll('.car-pontos button')];
    let atual = 0;
    let timer;

    function ir(i) {
      atual = (i + slides.length) % slides.length;
      trilho.style.transform = `translateX(-${atual * 100}%)`;
      pontos.forEach((p, n) => {
        p.classList.toggle('ativo', n === atual);
        p.setAttribute('aria-selected', n === atual);
      });
    }
    function iniciar() { parar(); timer = setInterval(() => ir(atual + 1), 6000); }
    function parar() { clearInterval(timer); }

    el.querySelector('.car-ant').addEventListener('click', () => { ir(atual - 1); iniciar(); });
    el.querySelector('.car-prox').addEventListener('click', () => { ir(atual + 1); iniciar(); });
    pontos.forEach((p) => p.addEventListener('click', () => { ir(Number(p.dataset.i)); iniciar(); }));
    el.addEventListener('mouseenter', parar);
    el.addEventListener('mouseleave', iniciar);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') { ir(atual - 1); iniciar(); }
      if (e.key === 'ArrowRight') { ir(atual + 1); iniciar(); }
    });

    let x0 = null;
    el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    el.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) { ir(atual + (dx < 0 ? 1 : -1)); iniciar(); }
      x0 = null;
    });

    ir(0);
    iniciar();
  };
})();
