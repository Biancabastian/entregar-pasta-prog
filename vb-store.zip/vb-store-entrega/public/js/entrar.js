(function () {
  const form = document.getElementById('autenticacaoForm');
  const msg = document.getElementById('autenticacaoMsg');
  const btn = document.getElementById('autenticacaoBtn');
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  const erro = (t) => { msg.textContent = t; msg.classList.add('erro'); };

  document.querySelector('[data-olho]').addEventListener('click', (e) => {
    const campo = document.getElementById('senha');
    const mostrar = campo.type === 'password';
    campo.type = mostrar ? 'text' : 'password';
    e.currentTarget.setAttribute('aria-label', mostrar ? 'Ocultar senha' : 'Mostrar senha');
  });

  document.getElementById('btnGoogle').addEventListener('click', () => {
    msg.classList.remove('erro');
    msg.textContent = 'O acesso com o Google ainda não está disponível. Use seu e-mail e senha.';
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    msg.textContent = '';
    const dados = Object.fromEntries(new FormData(form));
    if ('nome' in dados && dados.nome.trim().length < 2) return erro('Digite seu nome.');
    if (!EMAIL.test(dados.email.trim())) return erro('Digite um e-mail válido.');
    if (!dados.senha) return erro('Digite sua senha.');
    if ('senha2' in dados) {
      if (dados.senha.length < 6) return erro('A senha deve ter pelo menos 6 caracteres.');
      if (dados.senha !== dados.senha2) return erro('As senhas não são iguais.');
    }
    btn.disabled = true;
    try {
      const r = await fetch(form.dataset.acao, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome: dados.nome, email: dados.email, senha: dados.senha })
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.erro || 'Algo deu errado. Tente novamente.');
      location.href = '/';
    } catch (err) {
      erro(err.message);
      btn.disabled = false;
    }
  });
})();
