(function () {
  const VB = (window.VB = {});

  VB.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  VB.brl = (n) => Number(n).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  VB.api = async (url, opcoes = {}) => {
    const r = await fetch(url, {
      method: opcoes.method || 'GET',
      headers: { 'Content-Type': 'application/json' },
      body: opcoes.body ? JSON.stringify(opcoes.body) : undefined
    });
    const dados = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(dados.erro || 'Algo deu errado. Tente novamente.');
    return dados;
  };

  let tToast;
  VB.toast = (msg) => {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.classList.add('visivel');
    clearTimeout(tToast);
    tToast = setTimeout(() => el.classList.remove('visivel'), 2600);
  };

  VB.imagem = (p, hex) => (p.cores || []).find(c => c.hex === hex && c.imagem)?.imagem || p.imagem || (p.cores || []).find(c => c.imagem)?.imagem || '/img/logo.png';

  VB.favs = new Set();
  const coracao = '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 20.5s-8-4.9-8-11A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5c0 6.1-8 11-8 11z"/></svg>';

  VB.card = (p, opcoes) => {
    const fav = VB.favs.has(p.id);
    const parcela = VB.brl(p.preco / 3);
    return `
    <article class="card">
      <div class="card-img">
        <a href="/produto/${p.id}" aria-label="Ver detalhes de ${VB.esc(p.nome)}">
          <img src="${VB.imagem(p)}" alt="${VB.esc(p.nome)}" loading="lazy" width="400" height="500" class="${p.imagem ? 'foto' : ''}">
        </a>
        ${p.lancamento ? '<span class="selo">Lançamento</span>' : ''}
        <button class="fav-btn ${fav ? 'ativo' : ''}" data-fav="${p.id}" aria-pressed="${fav}" aria-label="${fav ? 'Remover dos' : 'Adicionar aos'} favoritos">${coracao}</button>
      </div>
      <div class="card-corpo">
        <h3><a href="/produto/${p.id}">${VB.esc(p.nome)}</a></h3>
        <div class="card-cores">${p.cores.map((c) => `<i style="background:${c.hex}" title="${VB.esc(c.nome)}"></i>`).join('')}</div>
        <p class="preco">
          ${p.preco_antigo ? `<s>${VB.brl(p.preco_antigo)}</s>` : ''}
          <strong>${VB.brl(p.preco)}</strong>
        </p>
        <p class="parcela">ou 3x de ${parcela} sem juros</p>
        <a href="/produto/${p.id}" class="btn btn-borda btn-bloco">Ver detalhes</a>
      </div>
    </article>`;
  };

  VB.desenharGrade = (el, lista, vazioEl) => {
    el.innerHTML = lista.map(VB.card).join('');
    if (vazioEl) vazioEl.hidden = lista.length > 0;
  };

  VB.mostrarContador = (id, n) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = n > 99 ? '99+' : n;
    el.hidden = !n;
  };
  VB.atualizarContadores = async () => {
    try {
      const [ids, carrinho] = await Promise.all([VB.api('/api/favoritos/ids'), VB.api('/api/carrinho')]);
      VB.favs = new Set(ids);
      VB.mostrarContador('contFav', ids.length);
      VB.mostrarContador('contCarrinho', carrinho.quantidade);
    } catch { /* offline */ }
  };

  VB.toggleFav = async (id) => {
    const r = await VB.api('/api/favoritos', { method: 'POST', body: { produto_id: id } });
    r.favorito ? VB.favs.add(id) : VB.favs.delete(id);
    VB.mostrarContador('contFav', r.total);
    document.querySelectorAll(`[data-fav="${id}"]`).forEach((b) => {
      b.classList.toggle('ativo', r.favorito);
      b.setAttribute('aria-pressed', r.favorito);
    });
    VB.toast(r.favorito ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
    document.dispatchEvent(new CustomEvent('favorito:alterado', { detail: { id, favorito: r.favorito } }));
  };

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-fav]');
    if (!btn) return;
    e.preventDefault();
    VB.toggleFav(Number(btn.dataset.fav)).catch((err) => VB.toast(err.message));
  });

  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-topo]')) window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  document.addEventListener('submit', async (e) => {
    if (e.target.id !== 'novidadesForm') return;
    e.preventDefault();
    const msg = document.getElementById('nlMsg');
    const campo = document.getElementById('nlEmail');
    msg.classList.remove('erro');
    try {
      const r = await VB.api('/api/novidades', { method: 'POST', body: { email: campo.value } });
      msg.textContent = r.mensagem;
      campo.value = '';
    } catch (err) {
      msg.textContent = err.message;
      msg.classList.add('erro');
    }
  });

  document.addEventListener('click', async (e) => {
    if (!e.target.closest('[data-sair]')) return;
    try { await VB.api('/api/autenticacao/sair', { method: 'POST' }); location.href = '/cadastro'; }
    catch (err) { VB.toast(err.message); }
  });
  document.addEventListener('submit', async (e) => {
    if (e.target.id !== 'perfilForm') return;
    e.preventDefault();
    const msg = document.getElementById('perfilMsg');
    msg.classList.remove('erro');
    try {
      const r = await VB.api('/api/autenticacao/perfil', { method: 'PATCH', body: { nome: document.getElementById('perfilNome').value } });
      msg.textContent = 'Nome atualizado.';
      document.querySelector('.perfil-avatar').textContent = r.usuario.nome.trim().charAt(0).toUpperCase();
    } catch (err) {
      msg.textContent = err.message;
      msg.classList.add('erro');
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    const pagina = document.body.dataset.pagina;
    document.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('ativo', a.dataset.nav === pagina));

    const menuBtn = document.getElementById('menuBtn');
    const nav = document.getElementById('nav');
    menuBtn.addEventListener('click', () => {
      const aberto = nav.classList.toggle('aberto');
      menuBtn.setAttribute('aria-expanded', aberto);
    });
    nav.addEventListener('click', (e) => { if (e.target.closest('a, button')) nav.classList.remove('aberto'); });

    const q = new URLSearchParams(location.search).get('q');
    if (q && pagina === 'busca') document.querySelector('.busca input').value = q;
  });
})();
