(function () {
  const pagina = document.body.dataset.pagina;
  const $ = (id) => document.getElementById(id);

  async function catalogo() {
    const grade = $('grade');
    const vazio = $('vazio');
    const chips = $('filtroGenero');
    const ordem = $('ordem');
    const q = new URLSearchParams(location.search).get('q') || '';

    const base = {
      home: { categoria: 'roupa' },
      feminino: { genero: 'feminino', categoria: 'roupa' },
      masculino: { genero: 'masculino', categoria: 'roupa' },
      acessorios: { categoria: 'acessorio' },
      busca: { q }
    }[pagina];
    const filtraPorChip = ['home', 'acessorios', 'busca'].includes(pagina);
    let generoChip = '';

    if (pagina === 'busca') {
      $('tituloCatalogo').textContent = q ? `Resultados para “${q}”` : 'Buscar';
    }
    if (chips && (filtraPorChip)) chips.hidden = false;

    const LIMITE = ['home', 'feminino', 'masculino'].includes(pagina) ? 20 : 0;
    const verMais = $('verMais');
    let lista = [];
    let expandido = false;

    function mostrar() {
      const visiveis = LIMITE && !expandido ? lista.slice(0, LIMITE) : lista;
      VB.desenharGrade(grade, visiveis, vazio);
      if (verMais) verMais.hidden = !(LIMITE && !expandido && lista.length > LIMITE);
    }

    async function carregar() {
      const params = new URLSearchParams(base);
      if (generoChip) params.set('genero', generoChip);
      if (ordem && ordem.value) params.set('ordem', ordem.value);
      grade.setAttribute('aria-busy', 'true');
      expandido = false;
      try {
        lista = await VB.api('/api/produtos?' + params);
        mostrar();
      } catch (e) {
        lista = [];
        grade.innerHTML = '';
        vazio.hidden = false;
        if (verMais) verMais.hidden = true;
        VB.toast(e.message);
      }
      grade.removeAttribute('aria-busy');
    }
    if (verMais) verMais.addEventListener('click', () => { expandido = true; mostrar(); });

    if (chips) {
      chips.addEventListener('click', (e) => {
        const chip = e.target.closest('.chip');
        if (!chip) return;
        chips.querySelectorAll('.chip').forEach((c) => c.classList.toggle('ativo', c === chip));
        generoChip = chip.dataset.genero;
        carregar();
      });
    }
    if (ordem) ordem.addEventListener('change', carregar);

    if (['home', 'feminino', 'masculino'].includes(pagina)) VB.carrossel(pagina, $('carrossel'));

    await VB.atualizarContadores();   
    carregar();
  }

  async function lancamentos() {
    const grade = $('grade');
    const vazio = $('vazio');
    const chips = $('filtroGenero');
    const ordem = $('ordem');
    const total = $('lanTotal');
    let filtro = '';

    async function carregar() {
      const params = new URLSearchParams({ lancamento: '1' });
      if (filtro === 'acessorio') params.set('categoria', 'acessorio');
      else if (filtro) { params.set('categoria', 'roupa'); params.set('genero', filtro); }
      if (ordem.value) params.set('ordem', ordem.value);
      grade.setAttribute('aria-busy', 'true');
      try {
        const lista = await VB.api('/api/produtos?' + params);
        VB.desenharGrade(grade, lista, vazio);
        total.textContent = lista.length === 1 ? '1 peça' : `${lista.length} peças`;
      } catch (e) {
        grade.innerHTML = '';
        vazio.hidden = false;
        total.textContent = '';
        VB.toast(e.message);
      }
      grade.removeAttribute('aria-busy');
    }

    chips.addEventListener('click', (e) => {
      const chip = e.target.closest('.chip');
      if (!chip) return;
      chips.querySelectorAll('.chip').forEach((c) => c.classList.toggle('ativo', c === chip));
      filtro = chip.dataset.filtro;
      carregar();
    });
    ordem.addEventListener('change', carregar);

    await VB.atualizarContadores();
    carregar();
  }

  async function favoritos() {
    await VB.atualizarContadores();
    const grade = $('grade');
    async function carregar() {
      const lista = await VB.api('/api/favoritos');
      VB.desenharGrade(grade, lista, null);
      $('vazio').hidden = lista.length > 0;
    }
    document.addEventListener('favorito:alterado', carregar);   
    carregar();
  }

  async function produto() {
    const id = Number(document.body.dataset.produtoId);
    const alvo = $('produto');
    let p;
    try { p = await VB.api('/api/produtos/' + id); } catch (e) { alvo.innerHTML = `<p class="vazio">${VB.esc(e.message)}</p>`; return; }
    await VB.atualizarContadores();

    VB.generoProduto = p.genero === 'masculino' ? 'masculino' : 'feminino';
    let cor = p.cores[0];
    let tamanho = p.tamanhos.length === 1 ? p.tamanhos[0] : null;
    let qtd = 1;
    const rotuloGenero = { feminino: 'Feminino', masculino: 'Masculino', unissex: 'Unissex' }[p.genero];
    const caminhoPai = p.categoria === 'acessorio' ? ['/acessorios', 'Acessórios'] : [`/${p.genero}`, rotuloGenero];
    const ehRoupa = p.categoria === 'roupa';
    const fotoCor = (c) => c.imagem || VB.imagem(p, c.hex);
    const fotoPorCor = p.cores.some((c) => c.imagem);
    const semMini = !!p.imagem && !fotoPorCor;

    alvo.innerHTML = `
      <nav class="migalhas" aria-label="Você está em"><a href="/">Início</a> / <a href="${caminhoPai[0]}">${caminhoPai[1]}</a> / <span>${VB.esc(p.nome)}</span></nav>
      <div class="produto-grade">
        <div class="galeria ${semMini ? 'sem-mini' : ''}">
          <div class="galeria-principal ${p.imagem ? 'foto' : ''}">
            <img id="imgProduto" src="${fotoCor(cor)}" alt="${VB.esc(p.nome)} na cor ${VB.esc(cor.nome)}" width="400" height="500">
            ${p.lancamento ? '<span class="selo">Lançamento</span>' : ''}
          </div>
          ${semMini
            ? `<p class="galeria-legenda">Foto na cor ${VB.esc(p.cores[0].nome)}</p>`
            : `<div class="galeria-mini" id="miniaturas">
            ${p.cores.map((c, i) => `<button type="button" class="${i === 0 ? 'ativo' : ''}" data-cor="${i}" aria-label="Cor ${VB.esc(c.nome)}"><img src="${fotoCor(c)}" alt="" width="80" height="100"></button>`).join('')}
          </div>`}
        </div>

        <div class="info">
          <p class="info-genero">${rotuloGenero} · ${ehRoupa ? 'Roupas' : 'Acessórios'}</p>
          <h1>${VB.esc(p.nome)}</h1>
          <p class="preco preco-grande">
            ${p.preco_antigo ? `<s>${VB.brl(p.preco_antigo)}</s>` : ''}
            <strong>${VB.brl(p.preco)}</strong>
          </p>
          <p class="parcela">ou 3x de ${VB.brl(p.preco / 3)} sem juros</p>
          <p class="info-desc">${VB.esc(p.descricao)}</p>

          <div class="opcao">
            <div class="opcao-topo"><span>Cor: <strong id="corNome">${VB.esc(cor.nome)}</strong></span></div>
            <div class="cores" id="cores" role="radiogroup" aria-label="Cores">
              ${p.cores.map((c, i) => `<button type="button" role="radio" aria-checked="${i === 0}" class="cor ${i === 0 ? 'ativo' : ''}" data-cor="${i}" style="--c:${c.hex}" title="${VB.esc(c.nome)}" aria-label="${VB.esc(c.nome)}"></button>`).join('')}
            </div>
          </div>

          <div class="opcao">
            <div class="opcao-topo">
              <span>Tamanho: <strong id="tamNome">${tamanho ? VB.esc(tamanho) : 'selecione'}</strong></span>
              ${ehRoupa ? '<button type="button" class="link-btn" data-abrir-provador>Descobrir meu tamanho no provador</button>' : ''}
            </div>
            <div class="tamanhos" id="tamanhos" role="radiogroup" aria-label="Tamanhos">
              ${p.tamanhos.map((t) => `<button type="button" role="radio" aria-checked="${t === tamanho}" class="tam ${t === tamanho ? 'ativo' : ''}" data-tam="${VB.esc(t)}">${VB.esc(t)}</button>`).join('')}
            </div>
          </div>

          <div class="opcao">
            <div class="opcao-topo"><span>Quantidade</span></div>
            <div class="qtd">
              <button type="button" id="menos" aria-label="Diminuir">−</button>
              <output id="qtd" aria-live="polite">1</output>
              <button type="button" id="mais" aria-label="Aumentar">+</button>
            </div>
          </div>

          <div class="info-acoes">
            <button class="btn btn-escuro" id="addCarrinho">Adicionar ao carrinho</button>
            <button class="btn btn-borda" id="comprarAgora">Comprar agora</button>
            <button class="fav-btn fav-grande ${VB.favs.has(p.id) ? 'ativo' : ''}" data-fav="${p.id}" aria-label="Favoritar" aria-pressed="${VB.favs.has(p.id)}">
              <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 20.5s-8-4.9-8-11A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5c0 6.1-8 11-8 11z"/></svg>
            </button>
          </div>

          <ul class="info-vantagens">
            <li>Frete grátis em compras acima de R$ 100,00</li>
            <li>Troca fácil em até 30 dias</li>
            <li>Compra 100% segura</li>
          </ul>

          <div class="detalhes">
            <details open><summary>Descrição</summary><p>${VB.esc(p.descricao)}</p></details>
            ${p.composicao ? `<details><summary>Composição</summary><p>${VB.esc(p.composicao)}</p></details>` : ''}
            ${p.cuidados ? `<details><summary>Cuidados</summary><p>${VB.esc(p.cuidados)}</p></details>` : ''}
          </div>
        </div>
      </div>`;

    const img = $('imgProduto');
    function escolherCor(i) {
      cor = p.cores[i];
      if (!semMini) img.src = fotoCor(cor);   
      img.alt = `${p.nome} na cor ${cor.nome}`;
      $('corNome').textContent = cor.nome;
      document.querySelectorAll('#cores .cor').forEach((b, n) => { b.classList.toggle('ativo', n === i); b.setAttribute('aria-checked', n === i); });
      document.querySelectorAll('#miniaturas button').forEach((b, n) => b.classList.toggle('ativo', n === i));
    }
    function escolherTamanho(t) {
      tamanho = t;
      $('tamNome').textContent = t;
      document.querySelectorAll('#tamanhos .tam').forEach((b) => { const on = b.dataset.tam === t; b.classList.toggle('ativo', on); b.setAttribute('aria-checked', on); });
    }

    alvo.addEventListener('click', (e) => {
      const c = e.target.closest('[data-cor]');
      if (c) return escolherCor(Number(c.dataset.cor));
      const t = e.target.closest('[data-tam]');
      if (t) return escolherTamanho(t.dataset.tam);
    });
    $('menos').addEventListener('click', () => { qtd = Math.max(1, qtd - 1); $('qtd').textContent = qtd; });
    $('mais').addEventListener('click', () => { qtd = Math.min(10, qtd + 1); $('qtd').textContent = qtd; });

    async function adicionar() {
      if (!tamanho) {
        VB.toast('Escolha um tamanho para continuar');
        $('tamanhos').classList.add('tremer');
        setTimeout(() => $('tamanhos').classList.remove('tremer'), 500);
        return false;
      }
      try {
        const c = await VB.api('/api/carrinho', { method: 'POST', body: { produto_id: p.id, cor: cor.nome, tamanho, quantidade: qtd } });
        VB.mostrarContador('contCarrinho', c.quantidade);
        return c;
      } catch (e) { VB.toast(e.message); return false; }
    }
    $('addCarrinho').addEventListener('click', async () => {
      const c = await adicionar();
      if (c) VB.toast(`Adicionado ao carrinho · Total ${VB.brl(c.total)}`);
    });
    $('comprarAgora').addEventListener('click', async () => { if (await adicionar()) location.href = '/carrinho'; });

    document.addEventListener('provador:tamanho', (e) => {
      const t = e.detail.tamanho;
      if (p.tamanhos.includes(t)) { escolherTamanho(t); VB.toast(`Tamanho ${t} selecionado`); }
      else VB.toast(`O tamanho ${t} não está disponível para esta peça`);
    });

    if (p.relacionados.length) {
      VB.desenharGrade($('relacionados'), p.relacionados);
      $('relacionadosSecao').hidden = false;
    }
  }

  async function carrinho() {
    function desenhar(c) {
      VB.mostrarContador('contCarrinho', c.quantidade);
      const vazio = c.itens.length === 0;
      $('vazio').hidden = !vazio;
      $('carrinhoConteudo').hidden = vazio;
      $('limpar').hidden = vazio;
      $('resumo').hidden = vazio;
      $('carrinhoQtd').textContent = vazio ? '' : `${c.quantidade} ${c.quantidade === 1 ? 'item' : 'itens'}`;
      $('itens').innerHTML = c.itens.map((i) => `
        <article class="item" data-id="${i.id}">
          <a href="/produto/${i.produto_id}" class="item-img"><img src="${i.imagem || '/img/logo.png'}" alt="${VB.esc(i.nome)}" width="90" height="112"></a>
          <div class="item-info">
            <h3><a href="/produto/${i.produto_id}">${VB.esc(i.nome)}</a></h3>
            <p class="item-meta">Cor: ${VB.esc(i.cor)} · Tamanho: ${VB.esc(i.tamanho)}</p>
            <p class="item-unit">${VB.brl(i.preco)} cada</p>
            <div class="qtd qtd-pequena">
              <button type="button" data-acao="menos" aria-label="Diminuir quantidade">−</button>
              <output>${i.quantidade}</output>
              <button type="button" data-acao="mais" aria-label="Aumentar quantidade">+</button>
            </div>
          </div>
          <div class="item-direita">
            <strong>${VB.brl(i.subtotal)}</strong>
            <button type="button" class="link-btn" data-acao="remover">Remover</button>
          </div>
        </article>`).join('');

      $('rSubtotal').textContent = VB.brl(c.subtotal);
      $('rFrete').textContent = c.frete === 0 ? 'Grátis' : VB.brl(c.frete);
      $('rTotal').textContent = VB.brl(c.total);
      $('rParcela').textContent = `ou ${c.parcelas}x de ${VB.brl(c.valorParcela)} sem juros`;
      const aviso = $('rAviso');
      aviso.hidden = !c.faltaFreteGratis;
      if (c.faltaFreteGratis) aviso.textContent = `Faltam ${VB.brl(c.faltaFreteGratis)} para ganhar frete grátis!`;
    }

    $('itens').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-acao]');
      if (!btn) return;
      const item = btn.closest('.item');
      const id = item.dataset.id;
      const atual = Number(item.querySelector('output').textContent);
      try {
        if (btn.dataset.acao === 'remover') desenhar(await VB.api('/api/carrinho/' + id, { method: 'DELETE' }));
        if (btn.dataset.acao === 'mais' && atual < 10) desenhar(await VB.api('/api/carrinho/' + id, { method: 'PATCH', body: { quantidade: atual + 1 } }));
        if (btn.dataset.acao === 'menos' && atual > 1) desenhar(await VB.api('/api/carrinho/' + id, { method: 'PATCH', body: { quantidade: atual - 1 } }));
      } catch (err) { VB.toast(err.message); }
    });

    $('limpar').addEventListener('click', async () => {
      if (confirm('Deseja esvaziar o carrinho?')) desenhar(await VB.api('/api/carrinho', { method: 'DELETE' }));
    });

    await VB.atualizarContadores();
    desenhar(await VB.api('/api/carrinho'));
  }

  document.addEventListener('DOMContentLoaded', () => {
    if (pagina === 'lancamentos') lancamentos();
    else if (['home', 'feminino', 'masculino', 'acessorios', 'busca'].includes(pagina)) catalogo();
    else if (pagina === 'favoritos') favoritos();
    else if (pagina === 'produto') produto();
    else if (pagina === 'carrinho') carrinho();
    else VB.atualizarContadores();
  });
})();
