const http = require('http');
const fs = require('fs');
const path = require('path');

const rotas = require('./routes');
const { json, html } = require('./util/http');
const { mostrar } = require('./util/mostra');
const { usuarioAtual } = require('./util/autenticacao');

const PORTA = Number(process.env.PORT) || 3000;
const PUBLIC = path.join(__dirname, 'public');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon', '.woff2': 'font/woff2'
};

function servirEstatico(url, res) {
  const arquivo = path.normalize(path.join(PUBLIC, decodeURIComponent(url.pathname)));
  if (!arquivo.startsWith(PUBLIC + path.sep)) return false;           
  let stat;
  try { stat = fs.statSync(arquivo); } catch { return false; }
  if (!stat.isFile()) return false;
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(arquivo).toLowerCase()] || 'application/octet-stream',
    'Cache-Control': 'no-cache'
  });
  fs.createReadStream(arquivo).pipe(res);
  return true;
}

const servidor = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && servirEstatico(url, res)) return;
    if (await rotas.resolver(req, res, url)) return;

    if (url.pathname.startsWith('/api/')) return json(res, 404, { erro: 'Rota não encontrada.' });
    html(res, 404, mostrar('404', { usuario: usuarioAtual(req), pagina: '404', titulo: 'Página não encontrada | VB Store', id: '' }));
  } catch (erro) {
    console.error(erro);
    if (res.headersSent) return res.end();
    json(res, 500, { erro: 'Erro interno do servidor.' });
  }
});

servidor.listen(PORTA, () => console.log(`VB Store rodando em http://localhost:${PORTA}`));
