# VB Store

Loja VB Store (versão de entrega: do início até o carrinho): Node.js + banco SQL (SQLite). As telas são **EJS** (`.ejs`). Funciona sem `npm install` (há um motor EJS embutido em `util/mostra.js`); se você rodar `npm install`, o pacote oficial `ejs` passa a ser usado automaticamente.

## Como rodar
Requer Node.js 22.5 ou superior. Use **`npm start`** (ele já liga o SQLite embutido nas versões 22.5 a 22.12). No Node 22.13+ também funciona `node server.js`.

```bash
npm start
```
Abra http://localhost:3000 (o banco é criado e populado automaticamente na primeira execução).

## Estrutura
```
vb-store-entrega/
├── server.js            servidor HTTP e arquivos estáticos
├── public/              arquivos públicos
│   ├── css/style.css
│   ├── js/              app.js, provador.js, carrossel.js, paginas.js, entrar.js
│   └── img/             coloque aqui as fotos dos modelos/produtos
│   └── partials/        head, header, footer, provador, fim
├── database/            schema.sql (tabelas), seed.js (produtos), db.js, resetar.js
├── routes/              paginas, produtos, favoritos, carrinho, provador, novidades, autenticacao
└── util/                rota, http, render (EJS), preco (total/frete), tamanhos (provador), svg
```

## Telas
| Rota | Conteúdo |
|---|---|
| `/` | Início: carrossel, 5 fileiras de roupas (filtro Todos/Feminino/Masculino) e seção "Sobre a loja" (`sobre` em `util/loja.js`) |
| `/feminino` | Carrossel + 5 fileiras de roupas femininas + "Sobre a loja" |
| `/masculino` | Carrossel + 5 fileiras de roupas masculinas + "Sobre a loja" |
| `/lancamentos` | Página própria de novidades (aberta pelo menu), com filtros e ordenação |
| `/acessorios` | Acessórios |
| `/produto/:id` | Detalhes: cores, tamanhos, quantidade, informações e compra |
| `/favoritos` | Peças favoritadas (coração) |
| `/carrinho` | Itens, quantidades e valor total somado (subtotal + frete). **É onde o projeto termina:** não há finalização de pedido. |
| `/entrar`, `/cadastro`, `/perfil` | Login, cadastro e perfil (nome, e-mail e sair da conta) |
| `/ajuda` | Frete, pagamento, trocas, guia de tamanhos e contato |

A logo sempre volta para `/`. O **Provador** abre em qualquer tela (menu, carrossel ou produto), recebe altura, peso, busto/peito, cintura e quadril e informa o tamanho ideal.

## API (rotas)
- `GET /api/produtos` (`genero`, `categoria`, `lancamento`, `promocao`, `q`, `ordem` (inclui `desconto`), `limite`) · `GET /api/produtos/:id` · `GET /api/slides?pagina=`
- `GET /api/favoritos` · `GET /api/favoritos/ids` · `POST /api/favoritos` `{produto_id}` (liga/desliga)
- `GET /api/carrinho` · `POST /api/carrinho` · `PATCH /api/carrinho/:id` · `DELETE /api/carrinho/:id` · `DELETE /api/carrinho`
- `POST /api/provador` · `GET /api/provador/tabela`

## Regras de valores (util/preco.js)
Frete grátis acima de R$ 100,00 (senão R$ 19,90) · parcelamento em até 3x sem juros.

## Logo, rodapé e contatos
- Logo: `public/img/logo.png` (cabeçalho), `public/img/logo-claro.png` (rodapé escuro) e `public/img/favicon.png` (aba do navegador).
- Telefone, e-mail, Instagram, horário e CNPJ do rodapé e da página de ajuda ficam em `util/loja.js` (campos vazios não aparecem).
- A novidades do rodapé grava os e-mails na tabela `novidades` do banco (`POST /api/novidades`).

## Fotos do site
- Carrossel: fotos em `public/img/banners/` (home-1..3, feminino-1..2, masculino-1..3). Cada slide é uma linha da tabela `slides` (colunas `imagem`, `alt`, textos e botão) em `database/seed.js`.
- Produtos: fotos em `public/img/produtos/`. Para uma foto diferente por cor, use `cor('Preto', '#161616', '/img/produtos/arquivo.jpg')` (exemplo: cinto, relógio e colar). Para colocar a foto de um produto, copie o arquivo para essa pasta e preencha `imagem: '/img/produtos/nome.jpg'` no produto em `database/seed.js`. Sem `imagem`, o produto usa a ilustração gerada em `util/svg.js`.
- Depois de mexer no `seed.js`, aumente `VERSAO_CATALOGO` em `database/db.js` (ou rode `npm run resetar-banco`) para o banco ser recriado.

## Banco de dados
Arquivo `database/vbstore.db`. Para recriar do zero: `npm run resetar-banco`.
Tabelas: produtos, slides, favoritos, carrinho, medidas_provador, usuarios, sessoes_login, novidades.


## Login, cadastro e perfil

- A primeira tela do site (`/`) é a de cadastro (`views/entrar.ejs`), com link para o login em `/entrar`.
  "Voltar para a loja" (`/loja`) deixa a pessoa navegar sem criar conta.
- O ícone do bonequinho abre `/perfil` (`views/perfil.ejs`): nome, e-mail e botão "Sair da conta".
  Sem login, o ícone leva para `/entrar`.
- Senhas são guardadas com scrypt (nunca em texto puro). A sessão fica num cookie HttpOnly de 30 dias.
- Código: `routes/autenticacao.js` (API `/api/autenticacao/cadastro|entrar|sair|eu|perfil`), `util/autenticacao.js`, tabelas `usuarios` e `sessoes_login` em `database/schema.sql`.
- A foto de fundo da tela de entrada é `public/img/login.jpg`.
- Ainda não existem: login com Google (o botão avisa que está indisponível) e recuperação de senha.



## Guia rápido: onde mexer em cada coisa

| Quero mudar...                              | Arquivo                                   |
|---------------------------------------------|-------------------------------------------|
| Cores, largura da página, espaço nas laterais | `public/css/style.css` (topo: `--largura`, `--lado`) |
| Posição do texto/botões do banner inicial   | `public/css/style.css` → `.car-texto`     |
| Textos de cada tela                         | `views/*.ejs`                             |
| Cabeçalho / rodapé (aparecem em todas)      | `views/partials/header.ejs`, `footer.ejs` |
| Produtos iniciais                           | `database/seed.js` |
| Como o site responde a cada endereço        | `routes/*.js` (um arquivo por assunto)    |

Cada arquivo começa com um comentário dizendo para que serve. O CSS é dividido em blocos com títulos (`/* ---- carrossel ---- */` etc.).

## O que foi retirado nesta versão
Painel de administração (`/admin`), finalização de pedido (`POST /api/carrinho/finalizar`) e histórico de pedidos no perfil.
