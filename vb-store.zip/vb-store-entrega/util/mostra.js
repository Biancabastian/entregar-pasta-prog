const fs = require('fs');
const path = require('path');

const VIEWS = path.join(__dirname, '..', 'views');

let ejsOficial = null;
try { ejsOficial = require('ejs'); } catch {  }

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const cache = new Map();

function compilar(fonte) {
  const re = /<%([=\-#]?)([\s\S]*?)(-)?%>(\r?\n)?/g;
  let pos = 0;
  let js = "let __o = '';\n";
  let m;
  const texto = (s) => { if (s) js += `__o += ${JSON.stringify(s)};\n`; };
  while ((m = re.exec(fonte))) {
    texto(fonte.slice(pos, m.index));
    const [, tipo, corpo, aparar, quebra] = m;
    if (tipo === '=') js += `__o += __esc(${corpo});\n`;
    else if (tipo === '-') js += `__o += __raw(${corpo});\n`;
    else if (tipo !== '#') js += corpo + '\n';
    if (quebra && !aparar) texto(quebra);
    pos = re.lastIndex;
  }
  texto(fonte.slice(pos));
  js += 'return __o;';
  return new Function('__d', '__esc', '__raw', 'include', `with (__d) {\n${js}\n}`);
}

function mostrarArquivo(arquivo, dados) {
  if (!path.extname(arquivo)) arquivo += '.ejs';
  let fn = cache.get(arquivo);
  if (!fn || process.env.NODE_ENV !== 'production') {
    fn = compilar(fs.readFileSync(arquivo, 'utf8'));
    cache.set(arquivo, fn);
  }
  const include = (rel, extra) => mostrarArquivo(path.resolve(path.dirname(arquivo), rel), { ...dados, ...extra });
  return fn(dados, esc, (v) => v ?? '', include);
}

const loja = require('./loja');
const PADRAO = { pagina: '', titulo: 'VB Store', id: '', cabecalho: '', texto: '', loja, usuario: null };

function mostrar(view, vars = {}) {
  const arquivo = path.join(VIEWS, view + '.ejs');
  const dados = { ...PADRAO, ...vars };
  if (ejsOficial) return ejsOficial.render(fs.readFileSync(arquivo, 'utf8'), dados, { filename: arquivo });
  return mostrarArquivo(arquivo, dados);
}

module.exports = { mostrar, esc };
