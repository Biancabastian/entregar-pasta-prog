const FRETE_GRATIS_ACIMA = 100;   
const VALOR_FRETE = 19.9;
const MAX_PARCELAS = 3;

const arredondar = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

function calcularTotais(itens) {
  const subtotal = arredondar(itens.reduce((s, i) => s + i.preco * i.quantidade, 0));
  const frete = itens.length === 0 || subtotal > FRETE_GRATIS_ACIMA ? 0 : VALOR_FRETE;
  const total = arredondar(subtotal + frete);
  const quantidade = itens.reduce((s, i) => s + i.quantidade, 0);
  return {
    quantidade,
    subtotal,
    frete,
    total,
    faltaFreteGratis: subtotal > 0 && subtotal <= FRETE_GRATIS_ACIMA ? arredondar(FRETE_GRATIS_ACIMA - subtotal + 0.01) : 0,
    parcelas: MAX_PARCELAS,
    valorParcela: arredondar(total / MAX_PARCELAS)
  };
}

module.exports = { calcularTotais, arredondar, FRETE_GRATIS_ACIMA, MAX_PARCELAS };
