module.exports = {
  nome: 'VB Store',
  slogan: 'Sua roupa, seu jeito.',
  horario: 'Segunda a sexta, das 9h às 18h',
  whatsapp: '',    
  email: '',       
  instagram: '',   
  cnpj: '',        

  sobre: {
    titulo: 'Moda para você se vestir do seu jeito.',
    texto: [
      'A VB Store nasceu para facilitar o que parece difícil: achar a peça certa, no tamanho certo, sem complicação. Reunimos roupas femininas, masculinas e acessórios em um só lugar, com cores e modelagens que combinam entre si.',
      'Por isso criamos o provador: você informa suas medidas e descobre o tamanho ideal antes de comprar. E, se mesmo assim a peça não servir, a troca é simples e acontece em até 30 dias.'
    ],
    pontos: [
      ['Provador com suas medidas', 'Descubra o tamanho ideal antes de comprar.'],
      ['Troca em até 30 dias', 'Peça sem uso, com etiqueta e na embalagem original.'],
      ['Frete grátis acima de R$ 100', 'E parcelamento em até 3x sem juros.']
    ]
  },


};
