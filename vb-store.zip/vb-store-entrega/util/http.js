const crypto = require('crypto');

function json(res, status, dados) {
  const corpo = JSON.stringify(dados);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(corpo);
}

function html(res, status, conteudo) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(conteudo);
}

function lerCorpo(req) {
  return new Promise((resolve, reject) => {
    let dados = '';
    req.on('data', (c) => {
      dados += c;
      if (dados.length > 1e6) { reject(new Error('Corpo muito grande')); req.destroy(); }
    });
    req.on('end', () => {
      if (!dados) return resolve({});
      try { resolve(JSON.parse(dados)); } catch { reject(new Error('JSON inválido')); }
    });
    req.on('error', reject);
  });
}

function lerBuffer(req, limite = 30 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const partes = [];
    let total = 0;
    req.on('data', (c) => {
      total += c.length;
      if (total > limite) { reject(new Error('Envio muito grande.')); req.destroy(); return; }
      partes.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(partes)));
    req.on('error', reject);
  });
}

function lerCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((par) => {
    const i = par.indexOf('=');
    if (i > 0) out[par.slice(0, i).trim()] = decodeURIComponent(par.slice(i + 1).trim());
  });
  return out;
}

function sessao(req, res) {
  let id = lerCookies(req).vb_sid;
  if (!id || !/^[a-f0-9-]{36}$/.test(id)) {
    id = crypto.randomUUID();
    res.setHeader('Set-Cookie', `vb_sid=${id}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax`);
  }
  return id;
}

function redirecionar(res, destino, cookies) {
  const cab = { Location: destino, 'Cache-Control': 'no-store' };
  if (cookies && cookies.length) cab['Set-Cookie'] = cookies;
  res.writeHead(302, cab);
  res.end();
}

module.exports = { json, html, lerCorpo, lerBuffer, lerCookies, sessao, redirecionar };
