const crypto = require('crypto');
const db = require('../database/db');
const { lerCookies } = require('./http');

const DIAS = 30;
const COOKIE = 'vb_autenticacao';       
const VISITANTE = 'vb_visitante'; 

const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

function hashSenha(senha) {
  const sal = crypto.randomBytes(16).toString('hex');
  return sal + ':' + crypto.scryptSync(senha, sal, 64).toString('hex');
}

function conferirSenha(senha, guardado) {
  const [sal, hash] = String(guardado).split(':');
  if (!sal || !hash) return false;
  const teste = crypto.scryptSync(senha, sal, 64);
  const original = Buffer.from(hash, 'hex');
  return original.length === teste.length && crypto.timingSafeEqual(original, teste);
}

function abrirSessao(usuarioId) {
  const token = crypto.randomBytes(32).toString('hex');
  const expira = Date.now() + DIAS * 86400000;
  db.prepare('DELETE FROM sessoes_login WHERE expira_em < ?').run(Date.now());
  db.prepare('INSERT INTO sessoes_login (token_hash, usuario_id, expira_em) VALUES (?, ?, ?)').run(sha(token), usuarioId, expira);
  const base = `Path=/; Max-Age=${DIAS * 86400}; SameSite=Lax`;
  return [`${COOKIE}=${token}; ${base}; HttpOnly`, `${VISITANTE}=1; ${base}`];
}

function fecharSessao(req) {
  const token = lerCookies(req)[COOKIE];
  if (token) db.prepare('DELETE FROM sessoes_login WHERE token_hash = ?').run(sha(token));
  const zerar = 'Path=/; Max-Age=0; SameSite=Lax';
  return [`${COOKIE}=; ${zerar}; HttpOnly`, `${VISITANTE}=; ${zerar}`];
}

function usuarioAtual(req) {
  const token = lerCookies(req)[COOKIE];
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const u = db.prepare(`SELECT u.id, u.nome, u.email, u.criado_em FROM sessoes_login s
    JOIN usuarios u ON u.id = s.usuario_id WHERE s.token_hash = ? AND s.expira_em > ?`).get(sha(token), Date.now());
  return u || null;
}

const tentativas = new Map();
function limitado(req) {
  const ip = req.socket.remoteAddress || '?';
  const agora = Date.now();
  const t = tentativas.get(ip);
  if (!t || t.ate < agora) { tentativas.set(ip, { n: 1, ate: agora + 15 * 60000 }); return false; }
  t.n += 1;
  return t.n > 10;
}
const liberar = (req) => tentativas.delete(req.socket.remoteAddress || '?');

const cookieVisitante = () => `${VISITANTE}=1; Path=/; Max-Age=${365 * 86400}; SameSite=Lax`;
const jaPassouPelaEntrada = (req) => lerCookies(req)[VISITANTE] === '1';

module.exports = { limitado, liberar, hashSenha, conferirSenha, abrirSessao, fecharSessao, usuarioAtual, cookieVisitante, jaPassouPelaEntrada };
