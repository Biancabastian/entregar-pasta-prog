const ORDEM = ['PP', 'P', 'M', 'G', 'GG'];

const TABELAS = {
  feminino: {
    busto:   [84, 89, 94, 100, 108],
    cintura: [66, 71, 76, 82, 90],
    quadril: [92, 97, 102, 108, 116]
  },
  masculino: {
    busto:   [90, 96, 102, 110, 120],   
    cintura: [75, 81, 87, 95, 106]
  }
};

function indiceDoTamanho(limites, valor) {
  for (let i = 0; i < limites.length; i++) if (valor <= limites[i]) return i;
  return limites.length; 
}

function numero(v) {
  const n = Number(String(v ?? '').replace(',', '.'));
  return Number.isFinite(n) && n > 0 ? n : null;
}

function recomendar(entrada) {
  const genero = entrada.genero === 'masculino' ? 'masculino' : 'feminino';
  const medidas = {
    altura: numero(entrada.altura),
    peso: numero(entrada.peso),
    busto: numero(entrada.busto),
    cintura: numero(entrada.cintura),
    quadril: numero(entrada.quadril)
  };
  const caimento = ['justo', 'normal', 'folgado'].includes(entrada.caimento) ? entrada.caimento : 'normal';

  if (!medidas.busto && !medidas.cintura) {
    return { erro: genero === 'masculino'
      ? 'Informe ao menos a medida do peito ou da cintura.'
      : 'Informe ao menos a medida do busto ou da cintura.' };
  }
  const limites = { altura: [100, 230], peso: [30, 250], busto: [60, 160], cintura: [45, 160], quadril: [70, 180] };
  for (const [campo, [min, max]] of Object.entries(limites)) {
    if (medidas[campo] !== null && (medidas[campo] < min || medidas[campo] > max)) {
      return { erro: `Confira o valor de ${campo}: use centímetros (cm)${campo === 'peso' ? ' / quilos (kg)' : ''}.` };
    }
  }

  const tabela = TABELAS[genero];
  const indices = [];
  if (medidas.busto) indices.push(indiceDoTamanho(tabela.busto, medidas.busto));
  if (medidas.cintura) indices.push(indiceDoTamanho(tabela.cintura, medidas.cintura));
  if (genero === 'feminino' && medidas.quadril) indices.push(indiceDoTamanho(tabela.quadril, medidas.quadril));

  let indice = Math.max(...indices);
  const acimaDaTabela = indice >= ORDEM.length;
  indice = Math.min(indice, ORDEM.length - 1);

  let ajuste = 0;
  if (caimento === 'folgado') ajuste = 1;
  if (caimento === 'justo') ajuste = -1;
  const indiceFinal = Math.max(0, Math.min(ORDEM.length - 1, indice + ajuste));

  let observacao = '';
  if (acimaDaTabela) observacao = 'Suas medidas estão acima da nossa tabela. O GG é o mais próximo, mas recomendamos falar com o atendimento.';
  else if (medidas.altura && medidas.altura >= 185 && indiceFinal < ORDEM.length - 1) observacao = 'Como você é alta(o), se preferir peças mais compridas, considere também o tamanho ' + ORDEM[indiceFinal + 1] + '.';
  else if (caimento === 'folgado') observacao = 'Escolhemos um tamanho acima para um caimento mais solto.';
  else if (caimento === 'justo') observacao = 'Escolhemos um tamanho abaixo para um caimento mais ajustado ao corpo.';

  const tamanho = ORDEM[indiceFinal];
  const alternativa = indiceFinal < ORDEM.length - 1 ? ORDEM[indiceFinal + 1] : null;

  return {
    tamanho,
    alternativa,
    genero,
    observacao,
    resumo: `Com base nas suas medidas, o tamanho ideal para você é o ${tamanho}.`
  };
}

module.exports = { recomendar, ORDEM, TABELAS };
