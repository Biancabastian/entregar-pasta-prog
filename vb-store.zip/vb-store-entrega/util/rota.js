class Rota {
  constructor() {
    this.rotas = [];
  }

  add(metodo, caminho, handler) {
    const chaves = [];
    const escapado = caminho.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const rx = new RegExp('^' + escapado.replace(/:([a-zA-Z]+)/g, (_, k) => {
      chaves.push(k);
      return '([^/]+)';
    }) + '/?$');
    this.rotas.push({ metodo, rx, chaves, handler });
    return this;
  }

  get(caminho, handler) { return this.add('GET', caminho, handler); }
  post(caminho, handler) { return this.add('POST', caminho, handler); }
  patch(caminho, handler) { return this.add('PATCH', caminho, handler); }
  delete(caminho, handler) { return this.add('DELETE', caminho, handler); }

  usar(outro) {
    this.rotas.push(...outro.rotas);
    return this;
  }

  async resolver(req, res, url) {
    for (const r of this.rotas) {
      if (r.metodo !== req.method) continue;
      const m = r.rx.exec(url.pathname);
      if (!m) continue;
      req.params = {};
      r.chaves.forEach((k, i) => { req.params[k] = decodeURIComponent(m[i + 1]); });
      req.query = url.searchParams;
      await r.handler(req, res);
      return true;
    }
    return false;
  }
}

module.exports = Rota;
