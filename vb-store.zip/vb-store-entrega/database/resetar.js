const fs = require('fs');
const path = require('path');

const base = process.env.DB_FILE || path.join(__dirname, 'vbstore.db');
for (const ext of ['', '-wal', '-shm']) {
  try { fs.unlinkSync(base + ext); } catch { /* arquivo não existe */ }
}
require('./db');
console.log('Banco recriado com os dados iniciais.');
