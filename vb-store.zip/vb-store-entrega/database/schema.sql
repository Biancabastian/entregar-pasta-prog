
CREATE TABLE IF NOT EXISTS produtos (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  descricao     TEXT,
  composicao    TEXT,
  cuidados      TEXT,
  preco         REAL    NOT NULL,
  preco_antigo  REAL,
  genero        TEXT    NOT NULL CHECK (genero IN ('feminino','masculino','unissex')),
  categoria     TEXT    NOT NULL CHECK (categoria IN ('roupa','acessorio')),
  tipo          TEXT    NOT NULL,              -- usado para desenhar a ilustração (camisa, vestido...)
  lancamento    INTEGER NOT NULL DEFAULT 0,
  cores         TEXT    NOT NULL,              -- JSON: [{"nome":"Preto","hex":"#111111"}]
  tamanhos      TEXT    NOT NULL,              -- JSON: ["PP","P","M","G","GG"]
  estoque       INTEGER NOT NULL DEFAULT 50,
  imagem        TEXT,                          -- foto do produto: /img/produtos/arquivo.jpg (vazio = ilustração)
  criado_em     TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS slides (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  pagina      TEXT    NOT NULL CHECK (pagina IN ('home','feminino','masculino')),
  titulo      TEXT    NOT NULL,
  destaque    TEXT,                            -- palavra final em destaque no título
  subtitulo   TEXT,
  botao       TEXT    DEFAULT 'Explorar Coleção',
  link        TEXT    DEFAULT '/',
  produto_id  INTEGER REFERENCES produtos(id) ON DELETE SET NULL,
  imagem      TEXT,                            -- foto do carrossel: /img/banners/arquivo.jpg
  alt         TEXT,                            -- descrição da foto (acessibilidade)
  ordem       INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS favoritos (
  sessao      TEXT    NOT NULL,
  produto_id  INTEGER NOT NULL REFERENCES produtos(id) ON DELETE CASCADE,
  criado_em   TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sessao, produto_id)
);

CREATE TABLE IF NOT EXISTS carrinho (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  sessao      TEXT    NOT NULL,
  produto_id  INTEGER NOT NULL REFERENCES produtos(id) ON DELETE CASCADE,
  cor         TEXT    NOT NULL,
  tamanho     TEXT    NOT NULL,
  quantidade  INTEGER NOT NULL DEFAULT 1 CHECK (quantidade > 0),
  UNIQUE (sessao, produto_id, cor, tamanho)
);

CREATE TABLE IF NOT EXISTS medidas_provador (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  sessao               TEXT,
  genero               TEXT,
  altura               REAL,
  peso                 REAL,
  busto_peito          REAL,
  cintura              REAL,
  quadril              REAL,
  caimento             TEXT,
  tamanho_recomendado  TEXT,
  criado_em            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS usuarios (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nome        TEXT NOT NULL,
  email       TEXT NOT NULL UNIQUE,            -- sempre em minúsculas
  senha_hash  TEXT NOT NULL,                   -- scrypt: "salt:hash" (a senha nunca é guardada)
  criado_em   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessoes_login (
  token_hash  TEXT PRIMARY KEY,                -- SHA-256 do token que fica no cookie
  usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  expira_em   INTEGER NOT NULL                 -- milissegundos (Date.now())
);

CREATE TABLE IF NOT EXISTS novidades (
  email      TEXT PRIMARY KEY,
  criado_em  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_produtos_genero ON produtos (genero, categoria);
CREATE INDEX IF NOT EXISTS idx_carrinho_sessao ON carrinho (sessao);
CREATE INDEX IF NOT EXISTS idx_favoritos_sessao ON favoritos (sessao);
