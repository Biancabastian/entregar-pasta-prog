
const TAM_ROUPA = ['PP', 'P', 'M', 'G', 'GG'];
const cor = (nome, hex, imagem) => (imagem ? { nome, hex, imagem } : { nome, hex });

const produtos = [
  { nome: 'Vestido Longo Noite', tipo: 'vestido', genero: 'feminino', categoria: 'roupa', preco: 189.9, preco_antigo: 249.9, lancamento: 1,
    descricao: 'Vestido longo em cetim com decote drapeado, alças finas e fenda lateral. Caimento fluido para eventos e noites especiais.',
    composicao: '95% poliéster acetinado, 5% elastano', cuidados: 'Lavar à mão em água fria. Não usar alvejante. Passar em temperatura baixa.',
    imagem: '/img/produtos/vestido-longo-vermelho.jpg',
    cores: [cor('Vermelho', '#9b1220', '/img/produtos/vestido-longo-vermelho.jpg'), cor('Azul Royal', '#1c2a8f', '/img/produtos/vestido-longo-azul.jpg'), cor('Marrom Chocolate', '#4a2a1d', '/img/produtos/vestido-longo-cetim-marrom.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Camisa Cetim Ana', tipo: 'camisa', genero: 'feminino', categoria: 'roupa', preco: 99.9, preco_antigo: null, lancamento: 0,
    descricao: 'Camisa de cetim com toque macio e brilho sutil. Combina com calças de alfaiataria e saias midi.',
    composicao: '100% poliéster acetinado', cuidados: 'Lavar à mão. Secar à sombra. Passar do avesso.',
    imagem: '/img/produtos/camisa-cetim-rosa.jpg',
    cores: [cor('Rosa', '#d4708a', '/img/produtos/camisa-cetim-rosa.jpg'), cor('Azul Céu', '#7f9fd0', '/img/produtos/camisa-cetim-azul.jpg'), cor('Preto', '#161616', '/img/produtos/camisa-cetim-preta.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Calça Pantalona Linho', tipo: 'calca', genero: 'feminino', categoria: 'roupa', preco: 159.9, preco_antigo: null, lancamento: 0,
    descricao: 'Calça pantalona de cintura alta em linho leve. Conforto e elegância para o dia a dia.',
    composicao: '55% linho, 45% viscose', cuidados: 'Lavar na máquina em ciclo delicado. Passar ainda úmida.',
    imagem: '/img/produtos/calca-pantalona-caramelo.jpg',
    cores: [cor('Caramelo', '#a9703c', '/img/produtos/calca-pantalona-caramelo.jpg'), cor('Cinza', '#8d8f93', '/img/produtos/calca-pantalona-cinza.jpg'), cor('Branco', '#f5f1ea', '/img/produtos/calca-pantalona-branca.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Saia Midi Plissada', tipo: 'saia', genero: 'feminino', categoria: 'roupa', preco: 129.9, preco_antigo: 159.9, lancamento: 1,
    descricao: 'Saia midi plissada com elástico na cintura e movimento incrível a cada passo.',
    composicao: '100% poliéster', cuidados: 'Lavar à mão. Não torcer. Secar na horizontal.',
    imagem: '/img/produtos/saia-plissada-verde.jpg',
    cores: [cor('Verde Esmeralda', '#0f4a32', '/img/produtos/saia-plissada-verde.jpg'), cor('Marrom', '#6b4a3a', '/img/produtos/saia-plissada-marrom.jpg'), cor('Off White', '#efe9dd', '/img/produtos/saia-plissada-off-white.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Cropped Canelado', tipo: 'cropped', genero: 'feminino', categoria: 'roupa', preco: 59.9, preco_antigo: null, lancamento: 0,
    descricao: 'Cropped em malha canelada com ótima elasticidade. Básico versátil para qualquer produção.',
    composicao: '95% algodão, 5% elastano', cuidados: 'Lavar na máquina em água fria. Não usar secadora.',
    imagem: '/img/produtos/cropped-rosa.jpg',
    cores: [cor('Rosa', '#e58fb3', '/img/produtos/cropped-rosa.jpg'), cor('Verde Oliva', '#6b7f3a', '/img/produtos/cropped-verde.jpg'), cor('Branco', '#f5f1ea', '/img/produtos/cropped-branco.jpg')], tamanhos: ['PP', 'P', 'M', 'G'] },
  { nome: 'Blazer Alfaiataria', tipo: 'blazer', genero: 'feminino', categoria: 'roupa', preco: 249.9, preco_antigo: 299.9, lancamento: 0,
    descricao: 'Blazer de alfaiataria com modelagem estruturada e forro interno. Sofisticação para o trabalho e além.',
    composicao: '70% poliéster, 28% viscose, 2% elastano', cuidados: 'Lavagem a seco recomendada.',
    imagem: '/img/produtos/blazer-marrom.jpg',
    cores: [cor('Marrom', '#4a2418', '/img/produtos/blazer-marrom.jpg'), cor('Branco', '#f5f1ea', '/img/produtos/blazer-branco.jpg'), cor('Preto', '#161616', '/img/produtos/blazer-preto.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Vestido Midi Linho', tipo: 'vestido', genero: 'feminino', categoria: 'roupa', preco: 169.9, preco_antigo: null, lancamento: 1,
    descricao: 'Vestido midi em linho com alças largas, decote quadrado e saia evasê. Leve, elegante e atemporal.',
    composicao: '55% linho, 45% viscose', cuidados: 'Lavar à mão em água fria. Passar ainda úmido.',
    imagem: '/img/produtos/vestido-midi-linho.jpg',
    cores: [cor('Bege Linho', '#d8c7a9'), cor('Terracota', '#b4654a')], tamanhos: TAM_ROUPA },
  { nome: 'Camisa Oversized Feminina', tipo: 'camisa', genero: 'feminino', categoria: 'roupa', preco: 119.9, preco_antigo: null, lancamento: 0,
    descricao: 'Camisa oversized de algodão com bolso frontal. Use fechada ou aberta sobre um top.',
    composicao: '100% algodão', cuidados: 'Lavar na máquina. Passar em temperatura média.',
    imagem: '/img/produtos/camisa-fem-amarela.jpg',
    cores: [cor('Amarelo', '#f1e38b', '/img/produtos/camisa-fem-amarela.jpg'), cor('Marrom', '#4a2a1d', '/img/produtos/camisa-fem-marrom.jpg'), cor('Off White', '#efe6d8', '/img/produtos/camisa-oversized-off-white.jpg')], tamanhos: TAM_ROUPA },

  { nome: 'Camisa Social Slim', tipo: 'camisa', genero: 'masculino', categoria: 'roupa', preco: 139.9, preco_antigo: null, lancamento: 0,
    descricao: 'Camisa social slim com algodão de toque macio e acabamento que não amassa fácil.',
    composicao: '97% algodão, 3% elastano', cuidados: 'Lavar na máquina. Passar em temperatura média.',
    imagem: '/img/produtos/camisa-social-azul-marinho.jpg',
    cores: [cor('Azul Marinho', '#1d2a4a', '/img/produtos/camisa-social-azul-marinho.jpg'), cor('Branco', '#f5f1ea', '/img/produtos/camisa-social-branca.jpg'), cor('Preto', '#161616', '/img/produtos/camisa-social-preta.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Camisa Oversized Manga Longa', tipo: 'camisa', genero: 'masculino', categoria: 'roupa', preco: 149.9, preco_antigo: 189.9, lancamento: 1,
    descricao: 'Camisa oversized de manga longa com bolso frontal e caimento solto. Elegância despojada para qualquer ocasião.',
    composicao: '60% linho, 40% algodão', cuidados: 'Lavar à mão ou ciclo delicado. Passar ainda úmida.',
    imagem: '/img/produtos/camisa-oversized-marrom.jpg',
    cores: [cor('Marrom', '#5a3a2a', '/img/produtos/camisa-oversized-marrom.jpg'), cor('Cinza Chumbo', '#6b6560', '/img/produtos/camisa-oversized-cinza.jpg'), cor('Branco', '#f5f1ea', '/img/produtos/camisa-oversized-branca.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Calça Chino', tipo: 'calca', genero: 'masculino', categoria: 'roupa', preco: 169.9, preco_antigo: null, lancamento: 0,
    descricao: 'Calça chino de sarja com elastano, corte reto e muito conforto.',
    composicao: '98% algodão, 2% elastano', cuidados: 'Lavar na máquina. Não usar alvejante.',
    imagem: '/img/produtos/calca-chino-azul-marinho.jpg',
    cores: [cor('Azul Marinho', '#1d2a4a', '/img/produtos/calca-chino-azul-marinho.jpg'), cor('Bege', '#cdbba4', '/img/produtos/calca-chino-bege.jpg'), cor('Preto', '#161616', '/img/produtos/calca-chino-preta.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Camiseta Básica Algodão', tipo: 'camiseta', genero: 'masculino', categoria: 'roupa', preco: 59.9, preco_antigo: null, lancamento: 0,
    descricao: 'Camiseta básica de algodão penteado, gola redonda e toque macio.',
    composicao: '100% algodão penteado', cuidados: 'Lavar na máquina em água fria.',
    imagem: '/img/produtos/camiseta-branca.jpg',
    cores: [cor('Branco', '#f5f1ea'), cor('Preto', '#161616'), cor('Cinza', '#8d8d8d'), cor('Marrom', '#6b4a3a')], tamanhos: TAM_ROUPA },
  { nome: 'Polo Piquet Clássica', tipo: 'polo', genero: 'masculino', categoria: 'roupa', preco: 99.9, preco_antigo: null, lancamento: 0,
    descricao: 'Polo em malha piquet com gola e punhos em ribana. Clássica e atemporal.',
    composicao: '100% algodão piquet', cuidados: 'Lavar na máquina. Não usar secadora.',
    imagem: '/img/produtos/polo-verde.jpg',
    cores: [cor('Verde', '#0f4a2a', '/img/produtos/polo-verde.jpg'), cor('Bordô', '#7a1020', '/img/produtos/polo-bordo.jpg'), cor('Azul Marinho', '#1d2a4a', '/img/produtos/polo-azul-marinho.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Jaqueta Jeans Clássica', tipo: 'jaqueta', genero: 'masculino', categoria: 'roupa', preco: 259.9, preco_antigo: 319.9, lancamento: 1,
    descricao: 'Jaqueta jeans com lavagem média, botões metálicos e bolsos frontais.',
    composicao: '100% algodão', cuidados: 'Lavar do avesso em água fria. Secar à sombra.',
    imagem: '/img/produtos/jaqueta-jeans.jpg',
    cores: [cor('Jeans', '#4d6a8c', '/img/produtos/jaqueta-jeans.jpg'), cor('Marrom', '#4a2a1d', '/img/produtos/jaqueta-marrom.jpg'), cor('Preto', '#161616', '/img/produtos/jaqueta-preta.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Bermuda Sarja', tipo: 'bermuda', genero: 'masculino', categoria: 'roupa', preco: 109.9, preco_antigo: null, lancamento: 0,
    descricao: 'Bermuda de sarja com corte reto e bolsos laterais. Conforto para o fim de semana.',
    composicao: '98% algodão, 2% elastano', cuidados: 'Lavar na máquina. Passar em temperatura média.',
    imagem: '/img/produtos/bermuda-azul-marinho.jpg',
    cores: [cor('Azul Marinho', '#1d2a4a', '/img/produtos/bermuda-azul-marinho.jpg'), cor('Bege', '#cdbba4', '/img/produtos/bermuda-bege.jpg'), cor('Preto', '#161616', '/img/produtos/bermuda-preta.jpg')], tamanhos: TAM_ROUPA },
  { nome: 'Suéter Tricot Gola Alta', tipo: 'sueter', genero: 'masculino', categoria: 'roupa', preco: 189.9, preco_antigo: null, lancamento: 1,
    descricao: 'Suéter em tricot trançado com gola alta e acabamento reforçado. Quente e elegante.',
    composicao: '70% algodão, 30% acrílico', cuidados: 'Lavar à mão. Secar na horizontal.',
    imagem: '/img/produtos/sueter-gola-alta.jpg',
    cores: [cor('Marrom', '#3e2418', '/img/produtos/sueter-gola-alta.jpg'), cor('Cinza Mescla', '#7a7a7a', '/img/produtos/sueter-cinza.jpg'), cor('Preto', '#161616', '/img/produtos/sueter-preto.jpg')], tamanhos: TAM_ROUPA },

  { nome: 'Óculos de Sol Retrô', tipo: 'oculos', genero: 'unissex', categoria: 'acessorio', preco: 129.9, preco_antigo: null, lancamento: 1,
    descricao: 'Óculos de sol com armação acetato e lentes com proteção UV400.',
    composicao: 'Armação em acetato, lentes policarbonato UV400', cuidados: 'Limpar com flanela macia. Guardar no estojo.',
    imagem: '/img/produtos/oculos-marrom.jpg',
    cores: [cor('Marrom', '#5a2e1c', '/img/produtos/oculos-marrom.jpg'), cor('Branco', '#f5f1ea', '/img/produtos/oculos-branco.jpg'), cor('Preto', '#161616', '/img/produtos/oculos-preto.jpg')], tamanhos: ['Único'] },
  { nome: 'Bolsa Estruturada', tipo: 'bolsa', genero: 'feminino', categoria: 'acessorio', preco: 219.9, preco_antigo: 269.9, lancamento: 0,
    descricao: 'Bolsa estruturada com alça de mão e alça transversal removível. Espaçosa e sofisticada.',
    composicao: 'Material sintético premium, forro em tecido', cuidados: 'Limpar com pano úmido. Evitar contato com água.',
    imagem: '/img/produtos/bolsa-vinho.jpg',
    cores: [cor('Vinho', '#6d1f33', '/img/produtos/bolsa-vinho.jpg'), cor('Off White', '#efe9dd', '/img/produtos/bolsa-off-white.jpg'), cor('Preto', '#161616', '/img/produtos/bolsa-preta.jpg')], tamanhos: ['Único'] },
  { nome: 'Cinto Couro Fivela', tipo: 'cinto', genero: 'masculino', categoria: 'acessorio', preco: 89.9, preco_antigo: null, lancamento: 0,
    descricao: 'Cinto de couro com fivela e ponteira trabalhadas em metal envelhecido. Detalhe marcante para qualquer look.',
    composicao: 'Couro, fivela em zamac', cuidados: 'Hidratar o couro periodicamente.',
    imagem: '/img/produtos/cinto-preto.jpg',
    cores: [cor('Preto', '#161616', '/img/produtos/cinto-preto.jpg'), cor('Marrom', '#5a3a28', '/img/produtos/cinto-marrom.jpg')], tamanhos: ['P', 'M', 'G'] },
  { nome: 'Relógio Minimalista', tipo: 'relogio', genero: 'unissex', categoria: 'acessorio', preco: 299.9, preco_antigo: 349.9, lancamento: 0,
    descricao: 'Relógio analógico minimalista com caixa em aço e pulseira de couro.',
    composicao: 'Caixa em aço inox, pulseira em couro', cuidados: 'Resistente a respingos. Não usar na água.',
    imagem: '/img/produtos/relogio-preto.jpg',
    cores: [cor('Preto', '#161616', '/img/produtos/relogio-preto.jpg'), cor('Marrom', '#5a3a28', '/img/produtos/relogio-marrom.jpg')], tamanhos: ['Único'] },
  { nome: 'Boné Aba Curva', tipo: 'bone', genero: 'unissex', categoria: 'acessorio', preco: 69.9, preco_antigo: null, lancamento: 1,
    descricao: 'Boné de sarja com aba curva e regulagem traseira.',
    composicao: '100% algodão', cuidados: 'Lavar à mão. Secar à sombra.',
    imagem: '/img/produtos/bone-vermelho.jpg',
    cores: [cor('Vermelho', '#b01025', '/img/produtos/bone-vermelho.jpg'), cor('Azul Marinho', '#1d2a4a', '/img/produtos/bone-azul.jpg'), cor('Preto', '#161616', '/img/produtos/bone-preto.jpg')], tamanhos: ['Único'] },
  { nome: 'Colar Pingente Retangular', tipo: 'colar', genero: 'unissex', categoria: 'acessorio', preco: 79.9, preco_antigo: null, lancamento: 0,
    descricao: 'Colar de corrente veneziana com pingente retangular liso. Delicado, minimalista e combina com tudo.',
    composicao: 'Latão com banho de ouro 18k ou ródio', cuidados: 'Evitar contato com perfumes e água.',
    imagem: '/img/produtos/colar-dourado.jpg',
    cores: [cor('Dourado', '#c9a24a', '/img/produtos/colar-dourado.jpg'), cor('Prateado', '#b8bcc2', '/img/produtos/colar-prateado.jpg')], tamanhos: ['Único'] }
];


const variante = (baseNome, corNome) => {
  const b = produtos.find((p) => p.nome === baseNome);
  const i = b.cores.findIndex((c) => c.nome === corNome);
  const c = b.cores[i];
  return { ...b, nome: `${b.nome} ${c.nome}`, imagem: c.imagem, cores: [c, ...b.cores.filter((_, j) => j !== i)] };
};
produtos.push(
  variante('Vestido Longo Noite', 'Azul Royal'), variante('Vestido Longo Noite', 'Marrom Chocolate'),
  variante('Camisa Cetim Ana', 'Azul Céu'), variante('Camisa Cetim Ana', 'Preto'),
  variante('Calça Pantalona Linho', 'Cinza'), variante('Calça Pantalona Linho', 'Branco'),
  variante('Saia Midi Plissada', 'Marrom'), variante('Saia Midi Plissada', 'Off White'),
  variante('Cropped Canelado', 'Verde Oliva'), variante('Blazer Alfaiataria', 'Branco'),
  variante('Blazer Alfaiataria', 'Preto'), variante('Camisa Oversized Feminina', 'Marrom'),

  variante('Camisa Social Slim', 'Branco'), variante('Camisa Social Slim', 'Preto'),
  variante('Camisa Oversized Manga Longa', 'Cinza Chumbo'), variante('Calça Chino', 'Bege'),
  variante('Calça Chino', 'Preto'), variante('Polo Piquet Clássica', 'Azul Marinho'),
  variante('Polo Piquet Clássica', 'Bordô'), variante('Jaqueta Jeans Clássica', 'Preto'),
  variante('Bermuda Sarja', 'Bege'), variante('Bermuda Sarja', 'Preto'),
  variante('Suéter Tricot Gola Alta', 'Cinza Mescla'), variante('Suéter Tricot Gola Alta', 'Preto')
);

const slides = [
  { pagina: 'home', titulo: 'Sua roupa,\nSeu', destaque: 'jeito.', subtitulo: 'Peças exclusivas para realçar sua essência em todos os momentos.', botao: 'Explorar Coleção', link: '#grade', imagem: '/img/banners/home-1.jpg', alt: 'Casal em frente a uma parede bege usando vestido longo azul-marinho e camisa de linho', ordem: 1 },
  { pagina: 'home', titulo: 'Atitude em\ncada', destaque: 'detalhe.', subtitulo: 'Cargos, pretos e streetwear para quem tem estilo próprio.', botao: 'Ver Lançamentos', link: '/lancamentos', imagem: '/img/banners/home-2.jpg', alt: 'Casal usando look todo preto com calças cargo', ordem: 2 },
  { pagina: 'home', titulo: 'Tons neutros,\nlook', destaque: 'perfeito.', subtitulo: 'Marrons e bege para produções leves e atemporais.', botao: 'Ver Coleção', link: '#grade', imagem: '/img/banners/home-3.jpg', alt: 'Casal usando calças cargo bege e camisetas marrons', ordem: 3 },

  { pagina: 'feminino', titulo: 'Feminino,\ncom', destaque: 'alma.', subtitulo: 'Vestidos, blusas e calças para brilhar em qualquer ocasião.', botao: 'Explorar Coleção', link: '#grade', imagem: '/img/banners/feminino-1.jpg', alt: 'Mulher com body marrom e calça cargo bege segurando uma bolsa', ordem: 1 },
  { pagina: 'feminino', titulo: 'Elegância que\nacompanha você', destaque: 'sempre.', subtitulo: 'Alfaiataria, linho e tecidos nobres para o dia a dia.', botao: 'Ver Lançamentos', link: '/lancamentos', imagem: '/img/banners/feminino-2.jpg', alt: 'Mulher com top marrom e saia longa de linho com fenda', ordem: 2 },

  { pagina: 'masculino', titulo: 'Masculino,\ncom', destaque: 'atitude.', subtitulo: 'Camisetas, cargos e peças com caimento perfeito.', botao: 'Explorar Coleção', link: '#grade', imagem: '/img/banners/masculino-1.jpg', alt: 'Homem de camiseta marrom e calça cargo bege', ordem: 1 },
  { pagina: 'masculino', titulo: 'Conforto\npara todos os', destaque: 'dias.', subtitulo: 'Camiseta oversized e bermuda para o seu fim de semana.', botao: 'Ver Lançamentos', link: '/lancamentos', imagem: '/img/banners/masculino-2.jpg', alt: 'Homem de camiseta preta e bermuda azul-marinho', ordem: 2 },
  { pagina: 'masculino', titulo: 'Estilo sem\nesforço,', destaque: 'sempre.', subtitulo: 'Básicos de qualidade para compor qualquer look.', botao: 'Ver Coleção', link: '#grade', imagem: '/img/banners/masculino-3.jpg', alt: 'Homem de camiseta azul-marinho e calça cargo cinza', ordem: 3 }
];

const ORDEM_VITRINE = [
  'Vestido Longo Noite', 'Polo Piquet Clássica', 'Saia Midi Plissada', 'Calça Chino', 'Camisa Cetim Ana', 'Jaqueta Jeans Clássica',
  'Cropped Canelado', 'Camisa Oversized Feminina', 'Bermuda Sarja', 'Camisa Social Slim', 'Suéter Tricot Gola Alta', 'Calça Pantalona Linho',
  'Blazer Alfaiataria', 'Camisa Oversized Manga Longa', 'Vestido Midi Linho', 'Camiseta Básica Algodão',
  'Vestido Longo Noite Azul Royal', 'Camisa Social Slim Branco', 'Saia Midi Plissada Marrom', 'Calça Chino Bege',
  'Camisa Cetim Ana Preto', 'Polo Piquet Clássica Azul Marinho', 'Blazer Alfaiataria Preto', 'Bermuda Sarja Bege',
  'Calça Pantalona Linho Cinza', 'Jaqueta Jeans Clássica Preto', 'Cropped Canelado Verde Oliva', 'Suéter Tricot Gola Alta Cinza Mescla',
  'Vestido Longo Noite Marrom Chocolate', 'Camisa Social Slim Preto', 'Saia Midi Plissada Off White', 'Calça Chino Preto',
  'Camisa Cetim Ana Azul Céu', 'Polo Piquet Clássica Bordô', 'Blazer Alfaiataria Branco', 'Bermuda Sarja Preto',
  'Calça Pantalona Linho Branco', 'Camisa Oversized Manga Longa Cinza Chumbo', 'Camisa Oversized Feminina Marrom', 'Suéter Tricot Gola Alta Preto',
  'Bolsa Estruturada', 'Boné Aba Curva', 'Óculos de Sol Retrô', 'Colar Pingente Retangular', 'Cinto Couro Fivela', 'Relógio Minimalista'
];

module.exports = function seed(db) {
  produtos.sort((a, b) => ORDEM_VITRINE.indexOf(a.nome) - ORDEM_VITRINE.indexOf(b.nome));
  const insProd = db.prepare(`INSERT INTO produtos
    (nome, descricao, composicao, cuidados, preco, preco_antigo, genero, categoria, tipo, lancamento, cores, tamanhos, estoque, imagem)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 50, ?)`);
  const ids = [];
  for (const p of produtos) {
    const r = insProd.run(p.nome, p.descricao, p.composicao, p.cuidados, p.preco, p.preco_antigo ?? null,
      p.genero, p.categoria, p.tipo, p.lancamento, JSON.stringify(p.cores), JSON.stringify(p.tamanhos), p.imagem ?? null);
    ids.push(Number(r.lastInsertRowid));
  }
  const insSlide = db.prepare(`INSERT INTO slides (pagina, titulo, destaque, subtitulo, botao, link, imagem, alt, ordem)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  for (const sl of slides) {
    insSlide.run(sl.pagina, sl.titulo, sl.destaque, sl.subtitulo, sl.botao, sl.link, sl.imagem, sl.alt, sl.ordem);
  }
};
