let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (e) {
  console.error('\nEste projeto usa o SQLite embutido do Node.js (node:sqlite).');
  console.error('Seu Node é a versão ' + process.versions.node + '. Rode com:  npm start');
  console.error('(ou: node --experimental-sqlite server.js). Também funciona sem flag no Node 22.13 ou mais novo.\n');
  process.exit(1);
}
const fs = require('fs');
const path = require('path');

const VERSAO_CATALOGO = 6;

const arquivo = process.env.DB_FILE || path.join(__dirname, 'vbstore.db');
const db = new DatabaseSync(arquivo);

db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
const versao = db.prepare('PRAGMA user_version').get().user_version;

if (versao < VERSAO_CATALOGO) {
  db.exec('DROP TABLE IF EXISTS carrinho; DROP TABLE IF EXISTS favoritos; DROP TABLE IF EXISTS slides; DROP TABLE IF EXISTS produtos;');
  db.exec(schema);
  require('./seed')(db);
  db.exec('PRAGMA user_version = ' + VERSAO_CATALOGO);
} else {
  db.exec(schema);
}

module.exports = db;
